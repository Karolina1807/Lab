const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// Створення папки 'archives' у корені проекту
const archivesDir = path.join(__dirname, 'archives');

if (!fs.existsSync(archivesDir)) {
    fs.mkdirSync(archivesDir, { recursive: true });
    console.log('Папку "archives" створено успішно.');
} else {
    console.log('Папка "archives" вже існує.');
}

// 1. CreateFileFunc
const createFileFunc = () => {
    const filePath = path.join(__dirname, 'files', 'fresh.txt');
    if (fs.existsSync(filePath)) {
        console.log('CREATE operation failed');
    } else {
        fs.writeFile(filePath, 'Свіжий і бадьорий', (err) => {
            if (err) throw err;
            console.log('File created successfully');
        });
    }
};

// 2. CopyFilesFunc
const copyFilesFunc = () => {
    const srcDir = path.join(__dirname, 'files');
    const destDir = path.join(__dirname, 'files_copy');

    if (!fs.existsSync(srcDir) || fs.existsSync(destDir)) {
        console.log('COPY operation failed');
        return;
    }

    fs.mkdir(destDir, { recursive: true }, (err) => {
        if (err) throw err;

        fs.readdir(srcDir, (err, files) => {
            if (err) throw err;

            files.forEach((file) => {
                const srcFile = path.join(srcDir, file);
                const destFile = path.join(destDir, file);

                fs.copyFile(srcFile, destFile, (err) => {
                    if (err) throw err;
                });
            });
            console.log('Files copied successfully');
        });
    });
};

// 3. RenameFileFunc
const renameFileFunc = () => {
    const oldPath = path.join(__dirname, 'files', 'wrongFilename.txt');
    const newPath = path.join(__dirname, 'files', 'properFilename.md');

    if (!fs.existsSync(oldPath) || fs.existsSync(newPath)) {
        console.log('RENAME operation failed');
        return;
    }

    fs.rename(oldPath, newPath, (err) => {
        if (err) throw err;
        console.log('File renamed successfully');
    });
};

// 4. DeleteFileFunc
const deleteFileFunc = () => {
    const filePath = path.join(__dirname, 'files', 'fileToRemove.txt');

    if (!fs.existsSync(filePath)) {
        console.log('DELETE operation failed');
        return;
    }

    fs.unlink(filePath, (err) => {
        if (err) throw err;
        console.log('File deleted successfully');
    });
};

// 5. ListFilesFunc
const listFilesFunc = () => {
    const dirPath = path.join(__dirname, 'files');

    if (!fs.existsSync(dirPath)) {
        console.log('LIST operation failed');
        return;
    }

    fs.readdir(dirPath, (err, files) => {
        if (err) throw err;
        files.forEach(file => console.log(file));
    });
};

// 6. ReadFileFunc
const readFileFunc = () => {
    const filePath = path.join(__dirname, 'files', 'fileToRead.txt');

    if (!fs.existsSync(filePath)) {
        console.log('READ operation failed');
        return;
    }

    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) throw err;
        console.log(data);
    });
};

// 7. ReadStreamFunc
const readStreamFunc = () => {
    const filePath = path.join(__dirname, 'files', 'fileToRead.txt');

    if (!fs.existsSync(filePath)) {
        console.log('READ STREAM operation failed');
        return;
    }

    const readStream = fs.createReadStream(filePath, 'utf8');
    readStream.on('data', chunk => console.log(chunk));
    readStream.on('error', err => console.log(err));
};

// 8. WriteStreamFunc
const writeStreamFunc = (text) => {
    const filePath = path.join(__dirname, 'files', 'fileToWrite.txt');

    if (fs.existsSync(filePath)) {
        console.log('WRITE STREAM operation failed');
        return;
    }

    const writeStream = fs.createWriteStream(filePath);
    writeStream.write(text, 'utf8');
    writeStream.end();

    writeStream.on('finish', () => console.log('File written successfully'));
    writeStream.on('error', err => console.log(err));
};

// 9. CompressFunc
const compressFunc = () => {
    const filePath = path.join(__dirname, 'files', 'fileToCompress.txt');
    const archivePath = path.join(__dirname, 'archives', 'archive.gz');

    if (!fs.existsSync(filePath) || fs.existsSync(archivePath)) {
        console.log('COMPRESS operation failed');
        return;
    }

    const readStream = fs.createReadStream(filePath);
    const writeStream = fs.createWriteStream(archivePath);
    const gzip = zlib.createGzip();

    readStream.pipe(gzip).pipe(writeStream);

    writeStream.on('finish', () => console.log('File compressed successfully'));
    writeStream.on('error', err => console.log(err));
};

// 10. DecompressFunc
const decompressFunc = () => {
    const archivePath = path.join(__dirname, 'archives', 'archive.gz');
    const outputPath = path.join(__dirname, 'files', 'decompressedFile.txt');

    if (!fs.existsSync(archivePath) || fs.existsSync(outputPath)) {
        console.log('DECOMPRESS operation failed');
        return;
    }

    const readStream = fs.createReadStream(archivePath);
    const writeStream = fs.createWriteStream(outputPath);
    const gunzip = zlib.createGunzip();

    readStream.pipe(gunzip).pipe(writeStream);

    writeStream.on('finish', () => console.log('File decompressed successfully'));
    writeStream.on('error', err => console.log(err));
};

// Виклик функцій для тестування
createFileFunc();
copyFilesFunc();
renameFileFunc();
deleteFileFunc();
listFilesFunc();
readFileFunc();
readStreamFunc();
writeStreamFunc('Some content to write');
compressFunc();
decompressFunc();
