const { triangle } = require('./app');

console.log(triangle(3, "leg", 4, "leg"));